Top Level Class:

The top level class is Main.java

---------------------------------------------------


Logical operators: 

src/LogicalOperator

Physical operators:

src/Operators

PhysicalPlanBuilder:

src/LogicalOperator/PhysicalPlanBuilder.java
