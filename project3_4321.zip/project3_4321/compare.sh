
EXPECTED=$1
OUTPUT=$2
END=$3

for i in $(seq $1 $END); diff ${EXPECTED}/query${i} ${OUTPUT}/query${i}; done
