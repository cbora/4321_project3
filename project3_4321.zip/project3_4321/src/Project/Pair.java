package Project;

public class Pair {
	public int low;
	public int high;
	
	public Pair(int low, int high) {
		this.low = low;
		this.high = high;
	}
}
