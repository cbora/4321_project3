package Testing;

import IO.Configuration;

public class MyMain {

	public MyMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration config = new Configuration("/Users/cbora/Desktop/samples/interpreter_config_file.txt");
		config.printout();
	}

}
