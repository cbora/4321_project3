package IO;

public class Logger {
	
	private static Logger instance = null;
	private static int level = 0;  // print level
	
	public Logger() {
		// TODO Auto-generated constructor stub
	}
	
	public static Logger getInstance() {
		if (instance == null)
			instance = new Logger();
		return instance;
	}
	
	public void setLevel(int level) {
		this.level = level;
	}
	
	public void log(int level, int i) {
		if (level >= this.level)
			System.out.println(i);
	}

	public void log(int level, String s) {
		if (level >= this.level)
			System.out.println(s);
	}
}
