package IO;

public class BulkLoading {

	public BulkLoading() {
		// TODO Auto-generated constructor stub
	}

}
